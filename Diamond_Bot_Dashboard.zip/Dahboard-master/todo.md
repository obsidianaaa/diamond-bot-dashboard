✔ 1]  Creating base
✔ 2] creating navbar
✔ 3] creating home page
✔ 4] Auth with discord api
✔ 5] linking dashboard with discord bot
6] creating dashboard page
7] creating Guild page
8] Creating guild database
9] Premium page
10] Premium subscription system with Stripe
